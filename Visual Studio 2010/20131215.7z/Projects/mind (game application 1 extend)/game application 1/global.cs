﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    public class global
    {
        public int textroadline1;
        public int textroadlineeffect1 = 0;
        public int textroad1 = 1;
        public int textroadcounter1 = 1;

    }
}


