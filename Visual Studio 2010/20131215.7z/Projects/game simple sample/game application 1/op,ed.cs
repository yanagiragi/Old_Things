﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class opening
    {
        public static void OpeningDisplayMessage()
        {
            Console.WriteLine("歡迎來到XXX的世界!");
            Console.WriteLine("reserved input space etc.");
            //Console.WriteLine("reserved input space etc.");
           // Console.WriteLine("reserved input space etc.");
           // Console.WriteLine("reserved input space etc.");
           // Console.WriteLine("reserved input space etc.");
           // Console.WriteLine("reserved input space etc.");
           // Console.WriteLine("reserved input space etc.");

        }
    }

    class ending
    {
        public static void endingDisplayMessage()
        {
            Console.WriteLine("結束!");
            Console.WriteLine("reserved input space etc.");
            Console.WriteLine("reserved input space etc.");
            Console.WriteLine("reserved input space etc.");
            Console.WriteLine("reserved input space etc.");
            Console.WriteLine("reserved input space etc.");
            Console.WriteLine("reserved input space etc.");
            Console.WriteLine("reserved input space etc.");

        }
    }
}
